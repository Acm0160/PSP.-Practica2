package org.example;

import java.io.*;

/**
 * FiltraLineas: lee de la entrada estándar o archivo redirigido.
 * Muestra solo líneas con más de 20 caracteres.
 */
public class FiltraLineas {
    public static void main(String[] args) {
        try (BufferedReader br = args.length > 0
                ? new BufferedReader(new FileReader(args[0]))  // lectura de archivo opcional
                : new BufferedReader(new InputStreamReader(System.in))) {

            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.length() > 20) {
                    System.out.println(linea); // salida estándar
                }
            }

        } catch (IOException e) {
            System.err.println("Error leyendo la entrada: " + e.getMessage());
        }
    }
}


