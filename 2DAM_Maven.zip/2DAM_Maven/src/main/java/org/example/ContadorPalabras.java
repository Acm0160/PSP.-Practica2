package org.example;

import java.io.*;

/**
 * ContadorPalabras: lee de la entrada estándar o archivo redirigido.
 * Muestra el número total de palabras.
 */
public class ContadorPalabras {
    public static void main(String[] args) {
        long totalPalabras = 0;

        try (BufferedReader br = args.length > 0
                ? new BufferedReader(new FileReader(args[0]))  // lectura de archivo opcional
                : new BufferedReader(new InputStreamReader(System.in))) {

            String linea;
            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                if (!linea.isEmpty()) {
                    totalPalabras += linea.split("\\s+").length;
                }
            }

            System.out.println("Número total de palabras: " + totalPalabras);

        } catch (IOException e) {
            System.err.println("Error leyendo la entrada: " + e.getMessage());
        }
    }
}
