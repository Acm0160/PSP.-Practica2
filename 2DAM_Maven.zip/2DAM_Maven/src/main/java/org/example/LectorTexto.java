package org.example;

import java.io.*;

/**
 * LectorTexto: lee 'entrada.txt' y envía su contenido a salida estándar.
 * Funciona de manera individual con archivo o en tubería con System.out.
 */
public class LectorTexto {
    public static void main(String[] args) {
        File archivo = new File("entrada.txt");
        if (!archivo.exists()) {
            System.err.println("Error: 'entrada.txt' no encontrado.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea); // salida estándar
            }
        } catch (IOException e) {
            System.err.println("Error leyendo 'entrada.txt': " + e.getMessage());
        }
    }
}


